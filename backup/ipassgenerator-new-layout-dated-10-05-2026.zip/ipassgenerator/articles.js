(function () {
  const ARTICLE_CONTAINER_ID = 'related-articles';
  const ARTICLE_LINK_CLASS = 'block text-sky-400 transition hover:text-sky-300';
  const YEAR_HEADING_CLASS = 'pt-0 pl-2 pb-1 rounded bg-sky-900 text-xl font-semibold uppercase tracking-[0.25em] text-white-300 first:pt-0';
  const ERROR_CLASS = 'block text-sm text-slate-300';

  const scriptBaseUrl = document.currentScript && document.currentScript.src
    ? new URL('.', document.currentScript.src).href
    : new URL(window.location.pathname.indexOf('article/') !== -1 ? '../' : './', window.location.href).href;

  function getDataUrl() {
    // Fetch from a deterministic absolute path so pages in /article/... work too.
    return new URL('ipassgenerator/data/articles.json', window.location.origin).href;
  }

  function parseDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) {
      return null;
    }

    const date = new Date(value + 'T00:00:00');
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function formatDayMonth(value) {
    const date = parseDate(value);
    if (!date) {
      return '';
    }

    const day = String(date.getDate()).padStart(2, '0');
    const month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][date.getMonth()];
    return day + ', ' + month;
  }

  function getYear(value) {
    const date = parseDate(value);
    return date ? String(date.getFullYear()) : '';
  }

  function resolveArticleUrl(url) {
    try {
      if (/^https?:\/\//i.test(url)) {
        return new URL(url);
      }

      return new URL(String(url || '').replace(/^\/+/, ''), scriptBaseUrl);
    } catch (e) {
      return new URL('.', scriptBaseUrl);
    }
  }

  function normalizeUrl(url) {
    return resolveArticleUrl(url).pathname.replace(/\/+$/, '');
  }

  function isCurrentArticle(article) {
    return normalizeUrl(article.url) === normalizeUrl(window.location.pathname);
  }

  function validateArticle(article) {
    return article
      && Number.isFinite(article.id)
      && typeof article.title === 'string'
      && article.title.trim()
      && typeof article.description === 'string'
      && typeof article.url === 'string'
      && article.url.trim()
      && typeof article.category === 'string'
      && article.category.trim()
      && parseDate(article.created)
      && parseDate(article.updated);
  }

  function validateArticles(data) {
    if (!Array.isArray(data)) {
      throw new Error('articles.json must contain an array.');
    }

    const articles = data.filter(validateArticle);
    if (!articles.length) {
      throw new Error('articles.json does not contain any valid articles.');
    }

    return articles.map(function (article) {
      return {
        id: article.id,
        title: article.title.trim(),
        description: article.description.trim(),
        url: article.url.trim(),
        category: article.category.trim(),
        created: article.created,
        updated: article.updated
      };
    });
  }

  function sortArticlesByCreatedDesc(articles) {
    return articles.slice().sort(function (a, b) {
      return parseDate(b.created).getTime() - parseDate(a.created).getTime() || a.id - b.id;
    });
  }

  function filterArticles(articles, options) {
    let filtered = articles.slice();

    if (options.category) {
      filtered = filtered.filter(function (article) {
        return article.category.toLowerCase() === options.category.toLowerCase();
      });
    }

    if (options.excludeCurrent) {
      filtered = filtered.filter(function (article) {
        return !isCurrentArticle(article);
      });
    }

    if (options.limit > 0) {
      filtered = filtered.slice(0, options.limit);
    }

    return filtered;
  }

  function groupArticlesByYear(articles) {
    return articles.reduce(function (groups, article) {
      const year = getYear(article.created);
      if (!groups[year]) {
        groups[year] = [];
      }
      groups[year].push(article);
      return groups;
    }, {});
  }

  function createYearHeading(year) {
    const heading = document.createElement('p');
    heading.className = YEAR_HEADING_CLASS;
    heading.textContent = '' + year;
    return heading;
  }

 function createArticleLink(article, options) {
  const link = document.createElement('a');
  const url = resolveArticleUrl(article.url).href;

  link.className = ARTICLE_LINK_CLASS;
  link.href = url;
  link.textContent = article.title;

  link.dataset.category = article.category;
  link.dataset.created = article.created;
  link.dataset.url = url;

  // Check if this is the current page
  if (window.location.href === url) {
    const span = document.createElement('span');
    span.textContent = article.title;

    // inline styling (no CSS file)
    span.style.color = 'white';
    span.style.cursor = 'default';

    span.dataset.category = article.category;
    span.dataset.created = article.created;
    span.dataset.url = url;

    return span; // return span instead of link
  }

  return link;
}

  function renderError(container, message) {
    container.replaceChildren();

    const error = document.createElement('p');
    error.className = ERROR_CLASS;
    error.textContent = message;
    container.appendChild(error);
  }

  function getRenderOptions(container) {
    return {
      category: container.dataset.category || '',
      excludeCurrent: container.dataset.excludeCurrent === 'true',
      limit: Number.parseInt(container.dataset.limit || '0', 10) || 0,
      showDate: container.dataset.showDate !== 'false'
    };
  }

  function renderArticleList(container, articles) {
    const options = getRenderOptions(container);
    const sorted = sortArticlesByCreatedDesc(articles);
    const filtered = filterArticles(sorted, options);
    const groups = groupArticlesByYear(filtered);
    const fragment = document.createDocumentFragment();

    Object.keys(groups)
      .sort(function (a, b) {
        return Number(b) - Number(a);
      })
      .forEach(function (year) {
        fragment.appendChild(createYearHeading(year));
        groups[year].forEach(function (article) {
          fragment.appendChild(createArticleLink(article, options));
        });
      });

    container.replaceChildren(fragment);
  }

  function renderCategoryFilters(container, articles) {
    const targetId = container.dataset.target || ARTICLE_CONTAINER_ID;
    const target = document.getElementById(targetId);
    const categories = Array.from(new Set(articles.map(function (article) {
      return article.category;
    }))).sort();

    container.replaceChildren();

    ['All'].concat(categories).forEach(function (category) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'rounded border border-slate-300 px-3 py-1 text-sm text-slate-700 transition hover:border-sky-500 hover:text-sky-600 dark:border-slate-700 dark:text-slate-200 dark:hover:text-sky-300';
      button.textContent = category;
      button.addEventListener('click', function () {
        if (target) {
          target.dataset.category = category === 'All' ? '' : category;
          renderArticleList(target, articles);
        }
      });
      container.appendChild(button);
    });
  }

  function renderMonthlyArchive(container, articles) {
    const archive = sortArticlesByCreatedDesc(articles).reduce(function (groups, article) {
      const date = parseDate(article.created);
      const key = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0');
      const label = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][date.getMonth()] + ' ' + date.getFullYear();
      groups[key] = groups[key] || { label: label, count: 0 };
      groups[key].count += 1;
      return groups;
    }, {});

    container.replaceChildren();

    Object.keys(archive).sort().reverse().forEach(function (key) {
      const item = document.createElement('p');
      item.className = 'text-sm text-slate-300';
      item.textContent = archive[key].label + ' (' + archive[key].count + ')';
      container.appendChild(item);
    });
  }

  function renderAll(articles) {
    document.querySelectorAll('#' + ARTICLE_CONTAINER_ID + ', [data-articles-widget="related"]').forEach(function (container) {
      renderArticleList(container, articles);
    });

    document.querySelectorAll('[data-articles-widget="latest"]').forEach(function (container) {
      container.dataset.limit = container.dataset.limit || '5';
      renderArticleList(container, articles);
    });

    document.querySelectorAll('[data-articles-widget="categories"]').forEach(function (container) {
      renderCategoryFilters(container, articles);
    });

    document.querySelectorAll('[data-articles-widget="archive"]').forEach(function (container) {
      renderMonthlyArchive(container, articles);
    });
  }

  function loadArticles() {
    var url = getDataUrl();

    return fetch(url, { cache: 'no-store' })
      .then(function (response) {
        if (!response.ok) {
          throw new Error(
            'Unable to load articles.json. URL=' + url + ' Status=' + response.status + ' ' + response.statusText
          );
        }
        return response.json();
      })
      .then(validateArticles)
      .catch(function (error) {
        // Surface fetch errors clearly (CORS, file://, 404, etc.)
        console.error('[iPassArticles] Failed to load:', url, error);
        throw error;
      });
  }

  function initArticles() {
    loadArticles()
      .then(renderAll)
      .catch(function (error) {
        document.querySelectorAll('#' + ARTICLE_CONTAINER_ID + ', [data-articles-widget]').forEach(function (container) {
          renderError(container, error.message);
        });
      });
  }

  window.iPassArticles = {
    load: loadArticles,
    render: renderAll,
    sortByCreatedDesc: sortArticlesByCreatedDesc,
    groupByYear: groupArticlesByYear
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initArticles);
  } else {
    initArticles();
  }
})();
