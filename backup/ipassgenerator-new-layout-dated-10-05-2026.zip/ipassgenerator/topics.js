(function () {
  const TOPICS_URL = 'article.json';

  function getTopicsUrl() {
    // Works from any route by using origin + absolute relative path.
    return new URL('ipassgenerator/data/category.json', window.location.origin).href;
  }

  function normalizeTopic(value) {
    if (typeof value !== 'string') return null;
    const t = value.trim();
    if (!t) return null;
    return t;
  }

  function buildTopicEl(topic) {
    const btn = document.createElement('button');
    btn.type = 'button';

    btn.style.cssText = [
    'background-color: #0e5194',
    'color: #ffffff',
    'font-weight: 400',
    'font-size: 12px',
    'padding: 8px 18px',
    'border-radius: 5px',
    'white-space: nowrap',
    'text-transform: uppercase',
    'letter-spacing: 0.5px',
    'box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2)',
    'transition: transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease',
    'margin-left: 0px'
    ].join(';');

    btn.textContent = topic;

    btn.addEventListener('click', function () {
      const url = new URL('article.html', window.location.href);
      url.searchParams.set('topic', topic);
      window.open(url.toString(), '_blank', 'noopener,noreferrer');
    });

    return btn;
  }

  async function loadTopics() {
    const url = getTopicsUrl();
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw new Error('Failed to load article.json. ' + res.status);

    const data = await res.json();
    if (!Array.isArray(data)) throw new Error('article.json must be an array.');

    const topics = data.map(normalizeTopic).filter(Boolean);
    return topics;
  }

  function renderTopics(container, topics) {
    container.replaceChildren();

    const fragment = document.createDocumentFragment();
    topics.forEach(function (topic) {
      fragment.appendChild(buildTopicEl(topic));
    });

    container.appendChild(fragment);
  }

  async function init() {
    const container = document.getElementById('article-topics-container');
    if (!container) return;

    try {
      const topics = await loadTopics();
      renderTopics(container, topics);
    } catch (e) {
      container.replaceChildren();
      const p = document.createElement('p');
      p.className = 'text-sm text-slate-500';
      p.textContent = 'Unable to load topics.';
      container.appendChild(p);
      console.error('[topics] ', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

